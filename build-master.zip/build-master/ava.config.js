export default {
  files: ['packages/**/tests/*.js', 'packages/**/tests/**/tests.js'],
  compileEnhancements: false,
  babel: false,
  verbose: true,
}
