// Patches `Array.flat()` and `Array.flatMap()`
// TODO: remove after dropping Node <12 support
require('array-flat-polyfill')
